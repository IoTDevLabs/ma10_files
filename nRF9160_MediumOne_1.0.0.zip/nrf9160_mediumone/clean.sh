set -x
/bin/rm -rf build/
