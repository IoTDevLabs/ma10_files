set -x
west build -b nrf9160_pca10090ns
