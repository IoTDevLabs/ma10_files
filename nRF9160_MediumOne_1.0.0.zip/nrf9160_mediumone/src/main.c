/*
 * Copyright (c) 2018 Nordic Semiconductor ASA
 *
 * SPDX-License-Identifier: LicenseRef-BSD-5-Clause-Nordic
 */

/* Asset Tracker application for nRF9160 DK and Medium One */

#include <zephyr.h>
#include <stdio.h>
#include <uart.h>
#include <string.h>

#include <net/mqtt.h>
#include <net/socket.h>
#include <lte_lc.h>
#if defined(CONFIG_LWM2M_CARRIER)
#include <lwm2m_carrier.h>
#endif
#include <dk_buttons_and_leds.h>
#include <gps.h>
#include "gps_controller.h"

/* Buffers for MQTT client */
static u8_t rx_buffer[CONFIG_MQTT_MESSAGE_BUFFER_SIZE];
static u8_t tx_buffer[CONFIG_MQTT_MESSAGE_BUFFER_SIZE];
static u8_t payload_buf[CONFIG_MQTT_PAYLOAD_BUFFER_SIZE];

/* The mqtt client struct */
static struct mqtt_client client;

/* MQTT Broker username & password */
static struct mqtt_utf8 mqtt_user_name = {
	.utf8 = (u8_t *)CONFIG_MQTT_BROKER_USERNAME,
	.size = sizeof(CONFIG_MQTT_BROKER_USERNAME) - 1
};

static struct mqtt_utf8 mqtt_password = {
	.utf8 = (u8_t *)CONFIG_MQTT_BROKER_PASSWORD,
	.size = sizeof(CONFIG_MQTT_BROKER_PASSWORD) - 1
};

/* MQTT Broker details. */
static struct sockaddr_storage broker;

/* MQTT connection status */
static bool connected;
static unsigned connect_attempt_count = 0;
static unsigned connect_success_count = 0;
static unsigned connect_fail_count = 0;
static unsigned disconnect_count = 0;

/* File descriptor */
static struct pollfd fds;

/* LEDs */
#define LED_ON(x)				(x)
#define LED_BLINK(x)			((x) << 8)
#define LED_GET_ON(x)			((x) & 0xFF)
#define LED_GET_BLINK(x)		(((x) >> 8) & 0xFF)
// nRF9160 DK LEDs:
//    DK_LED1_MSK
//    DK_LED2_MSK
//    DK_LED3_MSK
//    DK_LED4_MSK
//    DK_ALL_LEDS_MSK
//
#define LEDS_UPDATE_INTERVAL_MS		K_MSEC(500)
/* LED patterns */
enum {
	LEDS_OFF				= 0,
	LED1_ON					= LED_ON(DK_LED1_MSK),
	LED2_ON					= LED_ON(DK_LED2_MSK),
	LED3_ON					= LED_ON(DK_LED3_MSK),
	LED4_ON					= LED_ON(DK_LED4_MSK),
	LED1_BLINK				= LED_BLINK(DK_LED1_MSK),
	LED2_BLINK				= LED_BLINK(DK_LED2_MSK),
	LED3_BLINK				= LED_BLINK(DK_LED3_MSK),
	LED4_BLINK				= LED_BLINK(DK_LED4_MSK),
	LED_MODEM_CONNECTING	= LED1_BLINK,
	LED_MODEM_CONNECTED		= LED1_ON,
	LED_MQTT_CONNECTING		= LED2_BLINK,
	LED_MQTT_CONNECTED		= LED2_ON,
	LED_GPS_ACQUIRING		= LED3_BLINK,
	LED_GPS_FIX				= LED3_ON,
	LED_MQTT_PUBLISH		= LED4_ON,
} display_state;
#define DISPLAY_ON(pattern)		display_state |= pattern 
#define DISPLAY_OFF(pattern)	display_state &= ~(pattern)
#define DISPLAY_ON_OFF(on_pattern, off_pattern)		display_state = (display_state & ~(off_pattern)) | on_pattern 
static struct k_delayed_work leds_update_work;

/* MQTT publisher work item */
#define MQTT_PUBLISH_INTERVAL_MS	K_SECONDS(30)
static void mqtt_publish_work_fn(struct k_work *work);
static struct {
	bool active;
	struct k_delayed_work mqtt_publish_work;
	void (*work_fn)(struct k_work *);
	unsigned last_publish_time_ms;
	unsigned publish_count;
} mqtt_publisher = {
	.active = false,
	.work_fn = mqtt_publish_work_fn,
	.last_publish_time_ms = 0,
	.publish_count = 0
};

/* GPS sensor data */
static struct {
	bool gps_fix;
	double lat;
	double lon;
	float alt;
	float accuracy;
	float speed;
	float heading;
	char time[36];
	struct gps_data gps_data;
} gps_sensor = {
	.gps_fix = false,
	.lat = 0.0,
	.lon = 0.0,
	.alt = 0.0,
	.accuracy = 0.0,
	.speed = 0.0,
	.heading = 0.0,
	.time = { 0 }
};

/* GPS simulation data, when enabled */
#if defined(CONFIG_SIMULATED_GPS_TRACK)
static int sim_loc = 0;
static struct {
  double lat;
  double lon;
} gps_track[] = {
  { 39.234076, -98.272187 },
  { 39.234005, -98.233603 },
  { 39.233931, -98.186654 },
  { 39.221250, -98.154060 },
  { 39.195975, -98.153959 },
  { 39.176339, -98.154034 },
  { 39.156199, -98.153796 },
  { 39.136656, -98.153696 },
  { 39.110242, -98.150700 },
  { 39.082451, -98.151045 },
  { 39.051982, -98.151359 },
  { 39.052241, -98.178666 },
  { 39.052670, -98.214150 },
  { 39.048206, -98.240902 },
  { 39.046221, -98.246414 },
  { 39.045883, -98.262540 },
  { 39.045884, -98.280621 },
  { 39.055956, -98.280322 },
  { 39.068033, -98.279615 },
  { 39.080551, -98.279424 },
  { 39.094460, -98.279098 },
  { 39.111615, -98.278935 },
  { 39.121130, -98.278908 },
  { 39.129989, -98.277004 },
  { 39.132352, -98.281491 },
  { 39.138236, -98.284536 },
  { 39.150244, -98.284486 },
  { 39.161669, -98.284623 },
  { 39.172882, -98.284759 },
  { 39.185742, -98.284650 },
  { 39.199466, -98.284405 },
  { 39.211772, -98.284268 },
  { 39.226590, -98.284214 },
  { 39.234094, -98.284186 }
};
#endif

#if defined(CONFIG_BSD_LIBRARY)

/**@brief Recoverable BSD library error. */
void bsd_recoverable_error_handler(uint32_t err)
{
	printk("bsdlib recoverable error: %u\n", (unsigned int)err);
}

#endif /* defined(CONFIG_BSD_LIBRARY) */

#if defined(CONFIG_LWM2M_CARRIER)
K_SEM_DEFINE(carrier_registered, 0, 1);

void lwm2m_carrier_event_handler(const lwm2m_carrier_event_t *event)
{
	switch (event->type) {
	case LWM2M_CARRIER_EVENT_BSDLIB_INIT:
		printk("LWM2M_CARRIER_EVENT_BSDLIB_INIT\n");
		break;
	case LWM2M_CARRIER_EVENT_CONNECT:
		printk("LWM2M_CARRIER_EVENT_CONNECT\n");
		break;
	case LWM2M_CARRIER_EVENT_DISCONNECT:
		printk("LWM2M_CARRIER_EVENT_DISCONNECT\n");
		break;
	case LWM2M_CARRIER_EVENT_READY:
		printk("LWM2M_CARRIER_EVENT_READY\n");
		k_sem_give(&carrier_registered);
		break;
	case LWM2M_CARRIER_EVENT_FOTA_START:
		printk("LWM2M_CARRIER_EVENT_FOTA_START\n");
		break;
	case LWM2M_CARRIER_EVENT_REBOOT:
		printk("LWM2M_CARRIER_EVENT_REBOOT\n");
		break;
	}
}
#endif /* defined(CONFIG_LWM2M_CARRIER) */

/**@brief Function to print strings without null-termination
 */
static void data_print(u8_t *prefix, u8_t *data, size_t len)
{
	char buf[len + 1];

	memcpy(buf, data, len);
	buf[len] = 0;
	printk("%s%s\n", prefix, buf);
}

/**@brief Function to publish data on the configured topic
 */
static int data_publish(struct mqtt_client *c, enum mqtt_qos qos,
	u8_t *data, size_t len)
{
	struct mqtt_publish_param param;

	param.message.topic.qos = qos;
	param.message.topic.topic.utf8 = CONFIG_MQTT_PUB_TOPIC;
	param.message.topic.topic.size = strlen(CONFIG_MQTT_PUB_TOPIC);
	param.message.payload.data = data;
	param.message.payload.len = len;
	param.message_id = sys_rand32_get();
	param.dup_flag = 0;
	param.retain_flag = 0;

	data_print("Publishing: ", data, len);
	printk("to topic: %s len: %u\n",
		CONFIG_MQTT_PUB_TOPIC,
		(unsigned int)strlen(CONFIG_MQTT_PUB_TOPIC));

	return mqtt_publish(c, &param);
}

#if 0	/* not used */
/**@brief Function to subscribe to the configured topic
 */
static int subscribe(void)
{
	struct mqtt_topic subscribe_topic = {
		.topic = {
			.utf8 = CONFIG_MQTT_SUB_TOPIC,
			.size = strlen(CONFIG_MQTT_SUB_TOPIC)
		},
		.qos = MQTT_QOS_1_AT_LEAST_ONCE
	};

	const struct mqtt_subscription_list subscription_list = {
		.list = &subscribe_topic,
		.list_count = 1,
		.message_id = 1234
	};

	printk("Subscribing to: %s len %u\n", CONFIG_MQTT_SUB_TOPIC,
		(unsigned int)strlen(CONFIG_MQTT_SUB_TOPIC));

	return mqtt_subscribe(&client, &subscription_list);
}

/**@brief Function to read the published payload.
 */
static int publish_get_payload(struct mqtt_client *c, size_t length)
{
	u8_t *buf = payload_buf;
	u8_t *end = buf + length;

	if (length > sizeof(payload_buf)) {
		return -EMSGSIZE;
	}

	while (buf < end) {
		int ret = mqtt_read_publish_payload(c, buf, end - buf);

		if (ret < 0) {
			int err;

			if (ret != -EAGAIN) {
				return ret;
			}

			printk("mqtt_read_publish_payload: EAGAIN\n");

			err = poll(&fds, 1, K_SECONDS(CONFIG_MQTT_KEEPALIVE));
			if (err > 0 && (fds.revents & POLLIN) == POLLIN) {
				continue;
			} else {
				return -EIO;
			}
		}

		if (ret == 0) {
			return -EIO;
		}

		buf += ret;
	}

	return 0;
}
#endif

/**@brief MQTT client event handler
 */
void mqtt_evt_handler(struct mqtt_client *const c,
		      const struct mqtt_evt *evt)
{
#if 0	/* not used */
	int err;
#endif

	switch (evt->type) {
	case MQTT_EVT_CONNACK:
		/* Connected to broker */
		if (evt->result != 0) {
			printk("MQTT connect failed %d\n", evt->result);  // error codes in mqtt_socket.h
			connect_fail_count++;
			break;
		}

		connected = true;
		connect_success_count++;
		printk("[%s:%d] MQTT client connected!\n", __func__, __LINE__);
#if 0	/* not used */
		subscribe();
#endif
		/* Enable MQTT publish work */
		k_delayed_work_submit(&mqtt_publisher.mqtt_publish_work, K_NO_WAIT);
		mqtt_publisher.active = true;
		break;

	case MQTT_EVT_DISCONNECT:
		/* Disconnected from broker */
		printk("[%s:%d] MQTT client disconnected %d\n", __func__,
		       __LINE__, evt->result);

		connected = false;
		disconnect_count++;
		/* Disable MQTT publish work */
		if (mqtt_publisher.active) {
			k_delayed_work_cancel(&mqtt_publisher.mqtt_publish_work);
			mqtt_publisher.active = true;
		}
		break;

#if 0	/* not used */
	case MQTT_EVT_PUBLISH: {
		/* Received incoming message on subscribed topic */
		const struct mqtt_publish_param *p = &evt->param.publish;

		printk("[%s:%d] MQTT PUBLISH result=%d len=%d\n", __func__,
		       __LINE__, evt->result, p->message.payload.len);
		err = publish_get_payload(c, p->message.payload.len);
		if (err >= 0) {
			data_print("Received: ", payload_buf,
				p->message.payload.len);
			/* Echo back received data */
			data_publish(&client, MQTT_QOS_1_AT_LEAST_ONCE,
				payload_buf, p->message.payload.len);
		} else {
			printk("mqtt_read_publish_payload: Failed! %d\n", err);
			printk("Disconnecting MQTT client...\n");

			err = mqtt_disconnect(c);
			if (err) {
				printk("Could not disconnect: %d\n", err);
			}
		}
	} break;
#endif

	case MQTT_EVT_PUBACK:
		/* Publish acknowledgement */
		DISPLAY_OFF(LED_MQTT_PUBLISH);
		if (evt->result != 0) {
			printk("MQTT PUBACK error %d\n", evt->result);
			break;
		}

		printk("[%s:%d] PUBACK packet id: %u\n", __func__, __LINE__,
				evt->param.puback.message_id);
		break;

	case MQTT_EVT_SUBACK:
		/* Subscribe acknowledgement */
		if (evt->result != 0) {
			printk("MQTT SUBACK error %d\n", evt->result);  // error codes in mqtt_socket.h
			break;
		}

		printk("[%s:%d] SUBACK packet id: %u\n", __func__, __LINE__,
				evt->param.suback.message_id);
		break;

	default:
		printk("[%s:%d] default: %d\n", __func__, __LINE__,
				evt->type);
		break;
	}
}

/**@brief Resolves the configured hostname and
 * initializes the MQTT broker structure
 */
static void broker_init(void)
{
	int err;
	struct addrinfo *result;
	struct addrinfo *addr;
	struct addrinfo hints = {
		.ai_family = AF_INET,
		.ai_socktype = SOCK_STREAM
	};

	err = getaddrinfo(CONFIG_MQTT_BROKER_HOSTNAME, NULL, &hints, &result);
	if (err) {
		printk("ERROR: getaddrinfo failed %d\n", err);

		return;
	}

	addr = result;
	err = -ENOENT;

	/* Look for address of the broker. */
	while (addr != NULL) {
		/* IPv4 Address. */
		if (addr->ai_addrlen == sizeof(struct sockaddr_in)) {
			struct sockaddr_in *broker4 =
				((struct sockaddr_in *)&broker);
			char ipv4_addr[NET_IPV4_ADDR_LEN];

			broker4->sin_addr.s_addr =
				((struct sockaddr_in *)addr->ai_addr)
				->sin_addr.s_addr;
			broker4->sin_family = AF_INET;
			broker4->sin_port = htons(CONFIG_MQTT_BROKER_PORT);

			inet_ntop(AF_INET, &broker4->sin_addr.s_addr,
				  ipv4_addr, sizeof(ipv4_addr));
			printk("IPv4 Address found %s\n", ipv4_addr);

			break;
		} else {
			printk("ai_addrlen = %u should be %u or %u\n",
				(unsigned int)addr->ai_addrlen,
				(unsigned int)sizeof(struct sockaddr_in),
				(unsigned int)sizeof(struct sockaddr_in6));
		}

		addr = addr->ai_next;
		break;
	}

	/* Free the address. */
	freeaddrinfo(result);
}

/**@brief Initialize the MQTT client structure
 */
static void client_init(struct mqtt_client *client)
{

	mqtt_client_init(client);

	broker_init();

	/* MQTT client configuration */
	client->broker = &broker;
	client->evt_cb = mqtt_evt_handler;
	client->client_id.utf8 = (u8_t *)CONFIG_MQTT_CLIENT_ID;
	client->client_id.size = strlen(CONFIG_MQTT_CLIENT_ID);
	if (mqtt_user_name.size == 0) {
		printk("MQTT username & password are empty\n");
		client->user_name = NULL;
		client->password = NULL;
	} else {
		char tmp[128];
		strncpy(tmp, mqtt_user_name.utf8, mqtt_user_name.size);
		tmp[mqtt_user_name.size] = 0;
		printf("MQTT username = '%s'\n", tmp);
		strncpy(tmp, mqtt_password.utf8, mqtt_password.size);
		tmp[mqtt_password.size] = 0;
		printf("MQTT password = '%s'\n", tmp);
		client->user_name = &mqtt_user_name;
		client->password = &mqtt_password;
	}
	client->protocol_version = MQTT_VERSION_3_1_1;

	/* MQTT buffers configuration */
	client->rx_buf = rx_buffer;
	client->rx_buf_size = sizeof(rx_buffer);
	client->tx_buf = tx_buffer;
	client->tx_buf_size = sizeof(tx_buffer);

	/* MQTT transport configuration */
	client->transport.type = MQTT_TRANSPORT_NON_SECURE;
}

/**@brief Initialize the file descriptor structure used by poll.
 */
static int fds_init(struct mqtt_client *c)
{
	if (c->transport.type == MQTT_TRANSPORT_NON_SECURE) {
		fds.fd = c->transport.tcp.sock;
	} else {
#if defined(CONFIG_MQTT_LIB_TLS)
		fds.fd = c->transport.tls.sock;
#else
		return -ENOTSUP;
#endif
	}

	fds.events = POLLIN;

	return 0;
}

/**@brief Configures modem to provide LTE link. Blocks until link is
 * successfully established.
 */
static void modem_configure(void)
{
#if defined(CONFIG_LTE_LINK_CONTROL)
	if (IS_ENABLED(CONFIG_LTE_AUTO_INIT_AND_CONNECT)) {
		/* Do nothing, modem is already turned on
		 * and connected.
		 */
	} else {
#if defined(CONFIG_LWM2M_CARRIER)
		/* Wait for the LWM2M_CARRIER to configure the modem and
		 * start the connection.
		 */
		printk("Waiting for carrier registration...\n");
		k_sem_take(&carrier_registered, K_FOREVER);
		printk("Registered!\n");
#else /* defined(CONFIG_LWM2M_CARRIER) */
		int err;

		printk("LTE Link Connecting ...\n");
		err = lte_lc_init_and_connect();
		__ASSERT(err == 0, "LTE link could not be established.");
		printk("LTE Link Connected!\n");
#endif /* defined(CONFIG_LWM2M_CARRIER) */
	}
#endif /* defined(CONFIG_LTE_LINK_CONTROL) */
}

/**@brief Update LEDs state.
 */
static void leds_update(struct k_work *work)
{
	static bool led_on;
	static u8_t current_led_on_mask;
	u8_t led_on_mask = current_led_on_mask;

	ARG_UNUSED(work);

	/* Reset all leds. */
	led_on_mask &= ~(DK_ALL_LEDS_MSK);

	/* Set LEDs to match current state. */
	led_on_mask |= LED_GET_ON(display_state);

	led_on = !led_on;
	if (led_on) {
		led_on_mask |= LED_GET_BLINK(display_state);
	} else {
		led_on_mask &= ~LED_GET_BLINK(display_state);
	}

	if (led_on_mask != current_led_on_mask) {
		dk_set_leds(led_on_mask);
		current_led_on_mask = led_on_mask;
	}

	k_delayed_work_submit(&leds_update_work, LEDS_UPDATE_INTERVAL_MS);
}

/**@brief Work item function to publish MQTT data.
 */
static void mqtt_publish_work_fn(struct k_work *work)
{
	int err;
	unsigned current_time_ms = k_uptime_get_32();

	ARG_UNUSED(work);

	if (connected) {

#if defined(CONFIG_SIMULATED_GPS_TRACK)
		gps_sensor.gps_fix = true;
		gps_sensor.lat = gps_track[sim_loc].lat;
		gps_sensor.lon = gps_track[sim_loc].lon;
		if (++sim_loc >= sizeof(gps_track)/sizeof(gps_track[0])) {
			sim_loc = 0;
		}
#endif

		mqtt_publisher.publish_count++;

		/* Build JSON payload */

		sprintf(payload_buf, "{\"event_data\":{\"iteration\":%u,\"timestamp\":%u,\"gpsfix\":%s",
			mqtt_publisher.publish_count, current_time_ms, gps_sensor.gps_fix ? "true" : "false");

		if (gps_sensor.gps_fix) {
			sprintf(payload_buf + strlen(payload_buf), ",\"location\":\"%f %f\",\"gpstime\":\"%s\"",
				gps_sensor.lat, gps_sensor.lon, gps_sensor.time);
		}

		sprintf(payload_buf + strlen(payload_buf), "}}");

		/* Publish */

		DISPLAY_ON(LED_MQTT_PUBLISH);
		err = data_publish(&client, MQTT_QOS_1_AT_LEAST_ONCE, payload_buf, strlen(payload_buf));
		if (err != 0) {
			printk("ERROR: mqtt_publish %d\n", err);
		}

		mqtt_publisher.last_publish_time_ms = current_time_ms;

	}

#if defined(CONFIG_SIMULATED_GPS_TRACK)
	k_delayed_work_submit(&mqtt_publisher.mqtt_publish_work, MQTT_PUBLISH_INTERVAL_MS);
#endif
}

#if defined(CONFIG_GPS_ENABLED)

/**@brief GPS state change callback.
 */

static void gps_state_change_callback(unsigned new_state /* enum gps_state_e */)
{
	static unsigned last_state = GPS_IDLE;
	switch (new_state) {
		case GPS_ACQUIRING:
			DISPLAY_ON_OFF(LED_GPS_ACQUIRING, LED_GPS_FIX);
			break;
		case GPS_ACQUIRE_PAUSED:
			if (last_state == GPS_ACQUIRING) {
				gps_sensor.gps_fix = false;
				DISPLAY_OFF(LED_GPS_FIX | LED_GPS_ACQUIRING);
			}
			if (gps_sensor.gps_fix == false && mqtt_publisher.active == true) {
				k_delayed_work_submit(&mqtt_publisher.mqtt_publish_work, K_NO_WAIT);
			}
			break;
		case GPS_FIX:
			DISPLAY_ON_OFF(LED_GPS_FIX, LED_GPS_ACQUIRING);
			break;
		case GPS_IDLE:
		default:
			DISPLAY_OFF(LED_GPS_FIX | LED_GPS_ACQUIRING);
			break;
	}
	last_state = new_state;
}

/**@brief Callback for GPS trigger events.
 */
static void gps_trigger_handler(struct device *dev, struct gps_trigger *trigger)
{
	//static u32_t fix_count;
	char msg[256];

	ARG_UNUSED(trigger);

#if 0
	printk(">>> In gps_trigger_handler() ");

	switch (trigger->type) {
		case GPS_TRIG_TIMER:
			printk("GPS_TRIG_TIMER");
			break;
		case GPS_TRIG_DATA_READY:
			printk("GPS_TRIG_DATA_READY");
			break;
		case GPS_TRIG_FIX:
			printk("GPS_TRIG_FIX");
			break;
		default:
			printk("(unknown trigger type)");
			break;
	}

	printk("\n");
#endif

	//if (++fix_count < CONFIG_GPS_CONTROL_FIX_COUNT) {
	//	return;
	//}

	gps_state_change_callback(GPS_FIX);

	//fix_count = 0;

	gps_sample_fetch(dev);
	//gps_channel_get(dev, GPS_CHAN_NMEA, &gps_sensor.gps_data);  // GPS_CHAN_NMEA = NMEA strings, GPS_CHAN_PVT = position, velocity, time
	gps_channel_get(dev, GPS_CHAN_PVT,  &gps_sensor.gps_data);  // GPS_CHAN_NMEA = NMEA strings, GPS_CHAN_PVT = position, velocity, time

    sprintf(msg, "Got GPS fix: lat: %f, lon: %f, alt: %f, accuracy: %f, speed: %f, heading: %f, time: %04u-%02u-%02uT%02u:%02u:%02u.%03u000+00:00",
		gps_sensor.gps_data.pvt.latitude, gps_sensor.gps_data.pvt.longitude, gps_sensor.gps_data.pvt.altitude,
		gps_sensor.gps_data.pvt.accuracy, gps_sensor.gps_data.pvt.speed, gps_sensor.gps_data.pvt.heading,
		gps_sensor.gps_data.pvt.datetime.year, gps_sensor.gps_data.pvt.datetime.month, gps_sensor.gps_data.pvt.datetime.day,
		gps_sensor.gps_data.pvt.datetime.hour, gps_sensor.gps_data.pvt.datetime.minute, gps_sensor.gps_data.pvt.datetime.seconds,
		gps_sensor.gps_data.pvt.datetime.ms);
	printk("%s\n", msg);

	gps_sensor.lat = gps_sensor.gps_data.pvt.latitude;
	gps_sensor.lon = gps_sensor.gps_data.pvt.longitude;
	gps_sensor.alt = gps_sensor.gps_data.pvt.altitude;
	sprintf(gps_sensor.time, "%04u-%02u-%02uT%02u:%02u:%02u.%03u000+00:00",
		gps_sensor.gps_data.pvt.datetime.year, gps_sensor.gps_data.pvt.datetime.month, gps_sensor.gps_data.pvt.datetime.day,
		gps_sensor.gps_data.pvt.datetime.hour, gps_sensor.gps_data.pvt.datetime.minute, gps_sensor.gps_data.pvt.datetime.seconds,
		gps_sensor.gps_data.pvt.datetime.ms);
	gps_sensor.gps_fix = true;

	gps_control_stop(K_NO_WAIT);  // if stop GPS here, will wait CONFIG_GPS_CONTROL_FIX_CHECK_INTERVAL until try another fix

	k_delayed_work_submit(&mqtt_publisher.mqtt_publish_work, K_NO_WAIT);  // publish MQTT message
}

#endif  /* defined(CONFIG_GPS_ENABLED) */

/**@brief Main program.
 */
void main(void)
{
	int err;
	unsigned previous_time_ms = 0;
	unsigned current_time_ms;
	unsigned delta_time_ms;
	unsigned poll_time_ms;

	printk("The MQTT Medium One sample started\n");

#if defined(CONFIG_GPS_ENABLED)
	printk("CONFIG_GPS_ENABLED is defined, GPS functionality is enabled\n");
#else
	printk("CONFIG_GPS_ENABLED is not defined, GPS functionality is disabled\n");
#endif

#if defined(CONFIG_SIMULATED_GPS_TRACK)
	printk("CONFIG_SIMULATED_TRACK is defined, simulated GPS asset track is enabled\n");
#endif

	/* Initialize LED control */
	dk_leds_init();
	dk_set_leds(0);  // all off
	display_state = LEDS_OFF;
	k_delayed_work_init(&leds_update_work, leds_update);
	k_delayed_work_submit(&leds_update_work, LEDS_UPDATE_INTERVAL_MS);

	/* Start LTE connection */

	DISPLAY_ON(LED_MODEM_CONNECTING);

	modem_configure();

	DISPLAY_OFF(LED_MODEM_CONNECTING);
	DISPLAY_ON(LED_MODEM_CONNECTED);

	/* Connect to MQTT broker */

	client_init(&client);

	DISPLAY_ON(LED_MQTT_CONNECTING);

    printk("Connecting to MQTT broker...\n");

	connect_attempt_count++;
	err = mqtt_connect(&client);
	if (err != 0) {
		printk("ERROR: mqtt_connect %d\n", err);
		return;
	}

	DISPLAY_OFF(LED_MQTT_CONNECTING);
	DISPLAY_ON(LED_MQTT_CONNECTED);

	/* Initialize socket file descriptor for polling */

	err = fds_init(&client);
	if (err != 0) {
		printk("ERROR: fds_init %d\n", err);
		return;
	}

	/* Initialize MQTT publish work */

	k_delayed_work_init(&mqtt_publisher.mqtt_publish_work, mqtt_publisher.work_fn);

	/* Start GPS */

#if defined(CONFIG_SIMULATED_GPS_TRACK)
	printk("Using simulated GPS asset track\n");
#elif defined(CONFIG_GPS_ENABLED)
	printk("Starting GPS\n");
	err = gps_control_init(gps_trigger_handler);
	if (err != 0) {
		printk("ERROR: gps_control_init %d\n", err);
	} else {
		gps_set_state_callback_fn(gps_state_change_callback);
		gps_control_enable();
	}
#endif

	/* Start main loop */

	printk("Starting main loop\n");

	poll_time_ms = K_SECONDS(1);

	previous_time_ms = k_uptime_get_32();

	while (1) {

		/* Check for incoming traffic on MQTT socket */

		err = poll(&fds, 1, poll_time_ms);
		if (err < 0) {
			printk("ERROR: poll %d\n", errno);
			break;
		}

		/* fds.revents contains bit flags per ZSOCK_POLLxx in zephyr/include/net/socket.h:
         *
         *   POLLIN       0x0001    Incoming data is available.
         *   POLLOUT      0x0004    Poll for writability. 
         *   POLLERR      0x0008    Error on socket.
         *   POLLHUP      0x0010    Closed connection.
         *   POLLNVAL     0x0020    Invalid socket.
         */

		/* If something received, process via callback */

		if ((fds.revents & POLLIN) == POLLIN) {
			err = mqtt_input(&client);
			if (err != 0) {
				printk("ERROR: mqtt_input %d\n", err);
				break;
			}
		}

		/* Check for error conditions */

		if ((fds.revents & POLLERR) == POLLERR) {
			printk("ERROR: POLLERR socket error\n");
			DISPLAY_OFF(LED_MQTT_CONNECTING | LED_MQTT_CONNECTED);
			break;
		}

		if ((fds.revents & POLLNVAL) == POLLNVAL) {
			printk("ERROR: POLLNVAL socket invalid\n");
			DISPLAY_OFF(LED_MQTT_CONNECTING | LED_MQTT_CONNECTED);
			break;
		}
  
		if ((fds.revents & POLLHUP) == POLLHUP) {
			printk("ERROR: POLLHUP socket disconnected\n");
			DISPLAY_OFF(LED_MQTT_CONNECTING | LED_MQTT_CONNECTED);
			break;
		}

		current_time_ms = k_uptime_get_32();

		if (connected) {

				/* Check if need keepalive ping */

				delta_time_ms = current_time_ms - client.internal.last_activity;

				if (delta_time_ms >= K_SECONDS(CONFIG_MQTT_KEEPALIVE)) {
					/* Send MQTT ping */
					printk("Sending MQTT keepalive ping\n");
					err = mqtt_live(&client);
					if (err != 0) {
						printk("ERROR: mqtt_live %d\n", err);
						break;
					}
				}

		} else {

			/* Not currently connected */

			printk("Not connected\n");

			DISPLAY_OFF(LED_MQTT_CONNECTING | LED_MQTT_CONNECTED);

		}

	}

	printk("Disconnecting MQTT client...\n");

	err = mqtt_disconnect(&client);
	if (err) {
		printk("Could not disconnect MQTT client. Error: %d", err);
		switch (err) {
			case -(ENOTCONN):
				printk(" ENOTCONN: Socket is not connected");
				break;
			default:
				break;
		}
		printk("\n");
	}
}

