# ma10_files

Project application source code files for connecting Nordic nRF9160 DK to the Medium One IoT Prototyping Sandbox.

nRF9160_MediumOne_1.0.0.zip contains the project source code. It contains one directory named nrf9160_mediumone.
