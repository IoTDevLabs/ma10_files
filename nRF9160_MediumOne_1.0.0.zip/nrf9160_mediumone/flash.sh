set -x
west flash
